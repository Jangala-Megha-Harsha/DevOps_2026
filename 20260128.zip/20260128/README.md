# TechLearn Startup - React Dashboard

A simple front-end dashboard built with React to display welcome messages and course details using reusable UI components.

## 📋 Answers to Your Questions

### 1. How to Set Up a New React Project?

#### Using Vite (Recommended - Faster & Modern)
```bash
# Create a new Vite project
npm create vite@latest startup-dashboard -- --template react

# Navigate to project directory
cd startup-dashboard

# Install dependencies
npm install

# Start development server
npm run dev
```

#### Using Create React App (Traditional)
```bash
# Create a new React app
npx create-react-app startup-dashboard

# Navigate to project directory
cd startup-dashboard

# Start development server
npm start
```

**This project uses Vite** because it's:
- ⚡ Faster build times
- 🚀 Better development experience with Hot Module Replacement (HMR)
- 📦 Smaller bundle sizes
- 🔧 More modern and actively maintained

---

### 2. Role of package.json in a React Project

The `package.json` file is the **heart of your React project**. It serves multiple critical purposes:

#### Key Roles:
1. **Dependency Management**
   - Lists all libraries your project needs (react, react-dom, etc.)
   - Tracks versions to ensure consistency across environments
   ```json
   "dependencies": {
     "react": "^18.2.0",
     "react-dom": "^18.2.0"
   }
   ```

2. **Script Definitions**
   - Defines commands to run your application
   ```json
   "scripts": {
     "dev": "vite",        // Start development server
     "build": "vite build", // Create production build
     "preview": "vite preview" // Preview production build
   }
   ```

3. **Project Metadata**
   - Name, version, description, author information
   - Helps identify and document your project

4. **Development vs Production Dependencies**
   - `dependencies`: Required in production
   - `devDependencies`: Only needed during development (build tools, etc.)

5. **Version Control**
   - Allows other developers to install exact same dependencies using `npm install`

---

### 3. How to Create a Functional Component in React?

A **functional component** is a JavaScript function that returns JSX (React elements).

#### Basic Syntax:
```jsx
// Method 1: Function Declaration
function Welcome() {
  return <h1>Welcome to our dashboard!</h1>;
}

// Method 2: Arrow Function
const Welcome = () => {
  return <h1>Welcome to our dashboard!</h1>;
}

// Method 3: Arrow Function with implicit return (for simple components)
const Welcome = () => <h1>Welcome to our dashboard!</h1>;
```

#### Component with Props:
```jsx
function CourseCard({ title, description, price }) {
  return (
    <div className="course-card">
      <h3>{title}</h3>
      <p>{description}</p>
      <span>{price}</span>
    </div>
  );
}
```

#### Component with State and Logic:
```jsx
import React, { useState } from 'react';

function Counter() {
  const [count, setCount] = useState(0);
  
  const increment = () => setCount(count + 1);
  
  return (
    <div>
      <p>Count: {count}</p>
      <button onClick={increment}>Increment</button>
    </div>
  );
}
```

**Key Points:**
- Must start with a capital letter (e.g., `Welcome`, not `welcome`)
- Can accept props as parameters
- Must return JSX or null
- Can use React Hooks (useState, useEffect, etc.)

---

### 4. How Components are Rendered Inside the Main App Component

Components are rendered using **JSX composition** - placing components inside other components.

#### The Rendering Flow:

```jsx
// 1. Entry Point (main.jsx)
import ReactDOM from 'react-dom/client'
import App from './App.jsx'

ReactDOM.createRoot(document.getElementById('root')).render(<App />)

// 2. Main App Component (App.jsx)
import Welcome from './components/Welcome';
import CourseList from './components/CourseList';

function App() {
  const courses = [...]; // Course data
  
  return (
    <div className="App">
      {/* Rendering child components */}
      <Welcome />
      <CourseList courses={courses} />
    </div>
  );
}

// 3. Child Components
function Welcome() {
  return <div>Welcome Message</div>;
}

function CourseList({ courses }) {
  return (
    <div>
      {/* Rendering multiple instances of reusable component */}
      {courses.map(course => (
        <CourseCard key={course.id} course={course} />
      ))}
    </div>
  );
}
```

#### Key Concepts:
- **Self-closing tags**: `<Welcome />` for components without children
- **Props passing**: `<CourseList courses={courses} />` passes data down
- **Key prop**: `key={course.id}` helps React identify list items
- **Component tree**: App → Welcome + CourseList → Multiple CourseCards

---

### 5. Benefits of Breaking UI into Small Reusable Components

#### 🎯 Key Benefits:

1. **Reusability**
   - Write once, use multiple times
   - Example: `CourseCard` component used for each course
   ```jsx
   // Single component definition
   <CourseCard course={course1} />
   <CourseCard course={course2} />
   <CourseCard course={course3} />
   ```

2. **Maintainability**
   - Changes in one component don't affect others
   - Easy to locate and fix bugs
   - Update styling in one place, reflects everywhere

3. **Testability**
   - Test individual components in isolation
   - Easier to write unit tests
   - Faster debugging

4. **Readability**
   - Code is self-documenting
   - Clear component names describe purpose
   - Easier for team collaboration

5. **Scalability**
   - Add new features without breaking existing code
   - Easy to extend functionality
   - Components can be shared across projects

6. **Performance Optimization**
   - React can optimize re-renders at component level
   - Memoization works better with smaller components

7. **Separation of Concerns**
   - Each component has a single responsibility
   - Business logic separated from presentation
   - Easier to refactor

8. **Team Collaboration**
   - Different developers can work on different components
   - Reduces merge conflicts
   - Clear component boundaries

#### Example from Our Project:
```jsx
// ❌ Without components (Hard to maintain)
function App() {
  return (
    <div>
      <div className="course-card">...</div>
      <div className="course-card">...</div>
      <div className="course-card">...</div>
      <div className="course-card">...</div>
    </div>
  );
}

// ✅ With reusable components (Clean & Maintainable)
function App() {
  return (
    <div>
      {courses.map(course => (
        <CourseCard key={course.id} course={course} />
      ))}
    </div>
  );
}
```

---

## 🚀 Project Structure

```
startup-dashboard/
├── index.html              # Entry HTML file
├── package.json            # Project dependencies and scripts
├── vite.config.js          # Vite configuration
└── src/
    ├── main.jsx            # Application entry point
    ├── App.jsx             # Main App component
    ├── App.css             # App styles
    ├── index.css           # Global styles
    └── components/
        ├── Welcome.jsx     # Welcome message component
        ├── CourseCard.jsx  # Reusable course card component
        └── CourseList.jsx  # Course list container component
```

---

## 🎨 Component Architecture

```
App (Main Container)
├── Welcome (Static content)
│   └── Displays welcome message and tagline
└── CourseList (Dynamic content)
    └── CourseCard (Reusable)
        ├── Used for Course 1
        ├── Used for Course 2
        ├── Used for Course 3
        └── Used for Course 4
```

---

## 📦 Installation & Running

### Step 1: Install Dependencies
```bash
npm install
```

### Step 2: Start Development Server
```bash
npm run dev
```

The application will be available at `http://localhost:5173`

### Step 3: Build for Production
```bash
npm run build
```

---

## 🔍 Key React Concepts Demonstrated

1. **Functional Components**: All components use modern functional syntax
2. **Props**: Data passed from parent to child components
3. **JSX**: HTML-like syntax in JavaScript
4. **Component Composition**: Building complex UIs from simple components
5. **Array Mapping**: Rendering lists with `.map()`
6. **Component Reusability**: `CourseCard` used multiple times with different data

---

## 💡 Next Steps for Enhancement

1. Add React Router for multi-page navigation
2. Implement useState for interactive features (search, filter)
3. Connect to a backend API for dynamic data
4. Add form handling for course enrollment
5. Implement user authentication
6. Add animations and transitions
7. Create a responsive mobile design

---

## 📚 Learning Resources

- [React Official Documentation](https://react.dev/)
- [Vite Documentation](https://vitejs.dev/)
- [Modern JavaScript ES6+](https://javascript.info/)
- [React Hooks Guide](https://react.dev/reference/react)

---

**Created with ❤️ for TechLearn Startup**
